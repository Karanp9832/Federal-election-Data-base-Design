--task 4

DECLARE
    votedBefore BOOLEAN;
BEGIN
    votedBefore := previouslyVoted('Election 3', 'Electorate 3', 'Voter 3');
    IF votedBefore THEN
        DBMS_OUTPUT.PUT_LINE ('Voted before');
    ELSE 
        DBMS_OUTPUT.PUT_LINE ('Did not vote before');
    END IF;
END;
/


--here is the Stored procedure for task 4
---------
Select * from ballotIssuance;

CREATE OR REPLACE FUNCTION previouslyVoted(
    sp_electionCode VARCHAR2,
    sp_electorate VARCHAR2,
    sp_voterid VARCHAR2
) RETURN BOOLEAN AS 
    vt_count NUMBER(1);
BEGIN
    SELECT COUNT(*)
    INTO vt_count
    FROM ballotIssuance bi
    WHERE bi.electionevent_electionmaster_electionid = sp_electionCode
    AND bi.electionevent_electorate_electoratename = sp_electorate
    AND bi.voters_voterid = sp_voterid;

    IF vt_count > 0 THEN
        RETURN TRUE; -- Voter has voted before
    ELSE
        RETURN FALSE; -- Voter has not voted before
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        -- Handle exceptions, maybe log the error and raise it again
            DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
            RETURN FALSE; -- Return FALSE in case of an exception        
END previouslyVoted;
/