

CREATE TABLE ballot (
    ballotid                     VARCHAR2(10) NOT NULL,
    electionevent_electoratename VARCHAR2(100) NOT NULL,
    electionevent_electionid     VARCHAR2(20) NOT NULL
)
PARTITION BY LIST (electionevent_electionid)
(
    PARTITION p_election1 VALUES ('20190518'),
    PARTITION p_election2 VALUES ('20220518'),
    PARTITION p_other_events VALUES (DEFAULT) -- the ones that are not specified
);

ALTER TABLE ballot ADD CONSTRAINT ballot_pk PRIMARY KEY ( ballotid );

CREATE TABLE ballotissuance (
    pollingstationname                      VARCHAR2(50),
    timestamp                               TIMESTAMP WITH LOCAL TIME ZONE,
    issuedate                               DATE,
    voters_voterid                          VARCHAR2(20) NOT NULL, 

    electionevent_electorate_electoratename VARCHAR2(100) NOT NULL, 

    electionevent_electionmaster_electionid VARCHAR2(20) NOT NULL
)
PARTITION BY RANGE (issuedate)
(
    PARTITION issuance_before_2020 VALUES LESS THAN (TO_DATE('2020-01-01', 'YYYY-MM-DD')),
    PARTITION issuance_2020_to_2025 VALUES LESS THAN (TO_DATE('2025-01-01', 'YYYY-MM-DD')),
    PARTITION issuance_2025_to_2030 VALUES LESS THAN (TO_DATE('2030-01-01', 'YYYY-MM-DD')),
    PARTITION issuance_future VALUES LESS THAN (MAXVALUE)
);

ALTER TABLE ballotissuance ADD CONSTRAINT ballotissuance_pk PRIMARY KEY ( voters_voterid );

CREATE TABLE ballotpreff (
    prefference           INTEGER,
    ballot_ballotid       VARCHAR2(10) NOT NULL,
    candidate_candidateid VARCHAR2(10) NOT NULL,
    electoratename        VARCHAR2(100) NOT NULL,
    electionid            VARCHAR2(20) NOT NULL
)
PARTITION BY LIST (electionid) (
    PARTITION ballotPreff_election_1 VALUES ('20190518'),
    PARTITION ballotPreff_election_2 VALUES ('20220518'),
    PARTITION ballotPreff_election_3 VALUES ('20250518'),
    -- Add more partitions for other election IDs as needed
    PARTITION ballotPreff_default_other VALUES (DEFAULT)
);



ALTER TABLE ballotpreff ADD CONSTRAINT ballotpreff_pk PRIMARY KEY ( candidate_candidateid,
                                                                    ballot_ballotid );

CREATE TABLE candidate (
    candidateid              VARCHAR2(10) NOT NULL,
    candidatename            VARCHAR2(100),
    contactname              VARCHAR2(100),
    contactphone             VARCHAR2(30),
    contactemail             VARCHAR2(100),
    politicalparty_partycode VARCHAR2(50) NOT NULL
);

ALTER TABLE candidate ADD CONSTRAINT candidate_pk PRIMARY KEY ( candidateid );

CREATE TABLE electionevent (
    electorate_electoratename VARCHAR2(100) NOT NULL,
    electionmaster_electionid VARCHAR2(20) NOT NULL
);

ALTER TABLE electionevent ADD CONSTRAINT electionevent_pk PRIMARY KEY ( electorate_electoratename,
                                                                        electionmaster_electionid );

CREATE TABLE electionmaster (
    electionmasterid      NUMBER NOT NULL,
    electiondate          DATE,
    electiontype          VARCHAR2(50),
    totalelectorate       INTEGER,
    totalregisteredvoters INTEGER,
    electionid            VARCHAR2(20) NOT NULL
);

ALTER TABLE electionmaster ADD CONSTRAINT electionmaster_pk PRIMARY KEY ( electionid );

CREATE TABLE electionresults (
    primaryvotecount                        INTEGER,
    preferentialvotecount                   INTEGER, 

    electionevent_electorate_electoratename VARCHAR2(100) NOT NULL,
    candidate_candidateid                   VARCHAR2(10) NOT NULL, 

    electionevent_electionmaster_electionid VARCHAR2(20) NOT NULL
);

ALTER TABLE electionresults
    ADD CONSTRAINT electionresults_pk PRIMARY KEY ( electionevent_electorate_electoratename,
                                                    candidate_candidateid,
                                                    electionevent_electionmaster_electionid );

CREATE TABLE electorate (
    electoratename       VARCHAR2(100) NOT NULL,
    totalregiteredvoters INTEGER,
    currentmp            VARCHAR2(150)
);

ALTER TABLE electorate ADD CONSTRAINT electorate_pk PRIMARY KEY ( electoratename );

CREATE TABLE histvoterrec (
    hisrecdate                DATE,
    hisrecvoterscount         INTEGER,
    electorate_electoratename VARCHAR2(100) NOT NULL
);

ALTER TABLE histvoterrec ADD CONSTRAINT histvoterrec_pk PRIMARY KEY ( electorate_electoratename );

CREATE TABLE politicalparty (
    partycode          VARCHAR2(50) NOT NULL,
    partyname          VARCHAR2(100),
    partylogo          BLOB,
    partypostaladdress VARCHAR2(200),
    partysecretary     VARCHAR2(100),
    partycontactperson VARCHAR2(100),
    partycontactphone  VARCHAR2(30),
    partycontactemail  VARCHAR2(50)
);

ALTER TABLE politicalparty ADD CONSTRAINT politicalparty_pk PRIMARY KEY ( partycode );

CREATE TABLE prefdistribution (
    preffcount                    INTEGER NOT NULL,
    votecountround_roundno        INTEGER NOT NULL,
    votecountround_electoratename VARCHAR2(100) NOT NULL,
    votecountround_electionid     VARCHAR2(20) NOT NULL,
    candidate_candidateid         VARCHAR2(10) NOT NULL
);

ALTER TABLE prefdistribution
    ADD CONSTRAINT prefdistribution_pk PRIMARY KEY ( votecountround_roundno,
                                                     candidate_candidateid,
                                                     votecountround_electionid,
                                                     votecountround_electoratename );

CREATE TABLE votecountround (
    roundno                                 INTEGER NOT NULL,
    eliminatedcandidate                     VARCHAR2(50),
    votetodistribute                        INTEGER, 

    electionevent_electorate_electoratename VARCHAR2(100) NOT NULL, 

    electionevent_electionmaster_electionid VARCHAR2(20) NOT NULL
);

ALTER TABLE votecountround
    ADD CONSTRAINT votecountround_pk PRIMARY KEY ( roundno,
                                                   electionevent_electorate_electoratename,
                                                   electionevent_electionmaster_electionid );

CREATE TABLE voters (
    voterid            VARCHAR2(20) NOT NULL,
    title              VARCHAR2(15),
    firstname          VARCHAR2(25) NOT NULL,
    lastname           VARCHAR2(50) NOT NULL,
    middlename         VARCHAR2(50),
    gender             VARCHAR2(15),
    dateofbirth        DATE NOT NULL,
    residentialaddress VARCHAR2(200),
    postaladdress      VARCHAR2(200),
    contactdetails     VARCHAR2(100)
)
PARTITION BY RANGE (dateofbirth)
(
    PARTITION born_before_1970 VALUES LESS THAN (TO_DATE('1970-01-01', 'YYYY-MM-DD')),
    PARTITION born_before_1980 VALUES LESS THAN (TO_DATE('1980-01-01', 'YYYY-MM-DD')),
    PARTITION born_1980_to_1990 VALUES LESS THAN (TO_DATE('1990-01-01', 'YYYY-MM-DD')),
    PARTITION born_1990_to_2000 VALUES LESS THAN (TO_DATE('2000-01-01', 'YYYY-MM-DD')),
    PARTITION born_2000_to_2010 VALUES LESS THAN (TO_DATE('2010-01-01', 'YYYY-MM-DD')),
    PARTITION born_future VALUES LESS THAN (MAXVALUE)
);


ALTER TABLE voters ADD CONSTRAINT voters_pk PRIMARY KEY ( voterid );

ALTER TABLE ballot
    ADD CONSTRAINT ballot_electionevent_fk FOREIGN KEY ( electionevent_electoratename,
                                                         electionevent_electionid )
        REFERENCES electionevent ( electorate_electoratename,
                                   electionmaster_electionid );


ALTER TABLE ballotissuance
    ADD CONSTRAINT ballotissuance_electionevent_fk FOREIGN KEY ( electionevent_electorate_electoratename,
                                                                 electionevent_electionmaster_electionid )
        REFERENCES electionevent ( electorate_electoratename,
                                   electionmaster_electionid );

ALTER TABLE ballotissuance
    ADD CONSTRAINT ballotissuance_voters_fk FOREIGN KEY ( voters_voterid )
        REFERENCES voters ( voterid );

ALTER TABLE ballotpreff
    ADD CONSTRAINT ballotpreff_ballot_fk FOREIGN KEY ( ballot_ballotid )
        REFERENCES ballot ( ballotid );

ALTER TABLE ballotpreff
    ADD CONSTRAINT ballotpreff_candidate_fk FOREIGN KEY ( candidate_candidateid )
        REFERENCES candidate ( candidateid );

ALTER TABLE candidate
    ADD CONSTRAINT candidate_politicalparty_fk FOREIGN KEY ( politicalparty_partycode )
        REFERENCES politicalparty ( partycode );


ALTER TABLE electionevent
    ADD CONSTRAINT electionevent_electionmaster_fk FOREIGN KEY ( electionmaster_electionid )
        REFERENCES electionmaster ( electionid );

ALTER TABLE electionevent
    ADD CONSTRAINT electionevent_electorate_fk FOREIGN KEY ( electorate_electoratename )
        REFERENCES electorate ( electoratename );

ALTER TABLE electionresults
    ADD CONSTRAINT electionresults_candidate_fk FOREIGN KEY ( candidate_candidateid )
        REFERENCES candidate ( candidateid );


ALTER TABLE electionresults
    ADD CONSTRAINT electionresults_electionevent_fk FOREIGN KEY ( electionevent_electorate_electoratename,
                                                                  electionevent_electionmaster_electionid )
        REFERENCES electionevent ( electorate_electoratename,
                                   electionmaster_electionid );

ALTER TABLE histvoterrec
    ADD CONSTRAINT histvoterrec_electorate_fk FOREIGN KEY ( electorate_electoratename )
        REFERENCES electorate ( electoratename );

ALTER TABLE prefdistribution
    ADD CONSTRAINT prefdistribution_candidate_fk FOREIGN KEY ( candidate_candidateid )
        REFERENCES candidate ( candidateid );


ALTER TABLE prefdistribution
    ADD CONSTRAINT prefdistribution_votecountround_fk FOREIGN KEY ( votecountround_roundno,
                                                                    votecountround_electoratename,
                                                                    votecountround_electionid )
        REFERENCES votecountround ( roundno,
                                    electionevent_electorate_electoratename,
                                    electionevent_electionmaster_electionid );


ALTER TABLE votecountround
    ADD CONSTRAINT votecountround_electionevent_fk FOREIGN KEY ( electionevent_electorate_electoratename,
                                                                 electionevent_electionmaster_electionid )
        REFERENCES electionevent ( electorate_electoratename,
                                   electionmaster_electionid );




