--task 2 
------------

--answer 1

SELECT 
    e.electoratename as Electorate_Name,
    COUNT(DISTINCT bi.voters_voterid) AS total_number_of_voters
FROM  electorate e
JOIN electionevent ee ON e.electoratename = ee.electorate_electoratename
JOIN ballotissuance bi ON ee.electorate_electoratename = bi.electionevent_electorate_electoratename 
AND ee.electionmaster_electionid = bi.electionevent_electionmaster_electionid
GROUP BY e.electoratename
ORDER BY total_number_of_voters DESC;

--answer 2

    
    SELECT ee.electorate_electoratename AS "Electorate Name",c.candidatename AS "Candidate Name",pp.partyname AS "Political Party"
FROM electionevent ee
JOIN ballotpreff bp ON ee.electorate_electoratename = bp.electoratename AND ee.electionmaster_electionid = bp.electionid
JOIN candidate c ON bp.candidate_candidateid = c.candidateid
JOIN politicalparty pp ON c.politicalparty_partycode = pp.partycode
WHERE ee.electionmaster_electionid = 'Election 2'
ORDER BY ee.electorate_electoratename, DBMS_RANDOM.VALUE;

    
    
--answer 3

    
SELECT v.firstname, v.lastname,v.middleName, v.residentialaddress
FROM voters v
WHERE v.voterid NOT IN (SELECT bi.voters_voterid 
                        FROM ballotissuance bi
                        WHERE bi.electionevent_electionmaster_electionid IN ('Election 2', 'Election 4'));



 
--- first queri indexing


CREATE INDEX idx_ballotissuance_electorate_eventid ON ballotissuance(electionevent_electorate_electoratename, electionevent_electionmaster_electionid);



EXPLAIN PLAN FOR

SELECT 
    e.electoratename as Electorate_Name,
    COUNT(DISTINCT bi.voters_voterid) AS total_number_of_voters
FROM  electorate e
JOIN electionevent ee ON e.electoratename = ee.electorate_electoratename
JOIN ballotissuance bi ON ee.electorate_electoratename = bi.electionevent_electorate_electoratename 
AND ee.electionmaster_electionid = bi.electionevent_electionmaster_electionid
GROUP BY e.electoratename
ORDER BY total_number_of_voters DESC;


SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY);



--for the second queri indexing


CREATE INDEX index_electionevent_electionmaster_electorate ON electionevent (electionmaster_electionid, electorate_electoratename);

CREATE INDEX index_ballot_electionevent_electorate_election ON ballot (electionevent_electoratename, electionevent_electionid);

CREATE INDEX index_ballotpreff_ballot_candidate ON ballotpreff (ballot_ballotid, candidate_candidateid);

CREATE INDEX index_ballotpreff_electorate_electionid ON ballotpreff (electoratename, electionid);

---------------------

--Explain plan for Queri 2

EXPLAIN PLAN FOR


SELECT ee.electorate_electoratename AS "Electorate Name",c.candidatename AS "Candidate Name",pp.partyname AS "Political Party"
FROM electionevent ee
JOIN ballotpreff bp ON ee.electorate_electoratename = bp.electoratename AND ee.electionmaster_electionid = bp.electionid
JOIN candidate c ON bp.candidate_candidateid = c.candidateid
JOIN politicalparty pp ON c.politicalparty_partycode = pp.partycode
WHERE ee.electionmaster_electionid = 'Election 2'
ORDER BY ee.electorate_electoratename, DBMS_RANDOM.VALUE;

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY);




--for third queri indexing

CREATE INDEX index_ballotissuance_voterid_eventid ON ballotissuance(voters_voterid, electionevent_electionmaster_electionid);
CREATE INDEX index_ballotissuance_electionevent ON ballotissuance (electionevent_electionmaster_electionid);


--Execution plan

EXPLAIN PLAN FOR


SELECT v.firstname, v.lastname,v.middleName, v.residentialaddress
FROM voters v
WHERE v.voterid NOT IN (SELECT bi.voters_voterid 
                        FROM ballotissuance bi
                        WHERE bi.electionevent_electionmaster_electionid IN ('20220521', '20190518')); --change this


SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY);


-----------------------------------------------------------------------------------------------------------------------------------;
-----------------------------------------------------------------------------------------------------------------------------------;









