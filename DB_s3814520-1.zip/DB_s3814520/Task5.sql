---Task 5
------------------
CREATE OR REPLACE PROCEDURE primaryVoteCount(
    sp_electionCode VARCHAR2,
    sp_electorateName VARCHAR2
) AS
BEGIN
    -- Use MERGE to update if the record exists or insert if it doesn't
    MERGE INTO electionresults elr
    USING (
        SELECT candidate_candidateid, COUNT(*) AS primaryVotesCount
        FROM ballotpreff
        WHERE electionid  = sp_electionCode
        AND electoratename = sp_electorateName
        AND prefference = 1 -- First preference
        GROUP BY candidate_candidateid
    ) cbp
    ON (
        elr.electionevent_electionmaster_electionid = sp_electionCode
        AND  elr.electionevent_electorate_electoratename = sp_electorateName
        AND elr.candidate_candidateid = cbp.candidate_candidateid
    )
    WHEN MATCHED THEN 
        UPDATE SET elr.primaryvotecount = cbp.primaryVotesCount
    WHEN NOT MATCHED THEN
        INSERT (
            electionevent_electionmaster_electionid,
            electionevent_electorate_electoratename,
            candidate_candidateid,
            primaryvotecount
        )
        VALUES (
            sp_electionCode,
            sp_electorateName,
            cbp.candidate_candidateid,
            cbp.primaryVotesCount
        );
        
    COMMIT;  -- Add a COMMIT statement to make changes permanent

    -- Debugging
    DBMS_OUTPUT.PUT_LINE('Rows processed: ' || SQL%ROWCOUNT);
    
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error encountered: ' || SQLERRM);
        -- Alternatively, log to an error table or take other actions.
END primaryVoteCount;
/


--  run the primaryVoteCount procedure
BEGIN
    primaryVoteCount('Election 5', 'Electorate 5');
END;
/