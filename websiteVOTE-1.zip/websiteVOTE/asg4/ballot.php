<!DOCTYPE html>
<html>

<body>
   

    <?php
    // Connect to the database and query candidate names
    $username = 's3814520';
    $password = 'Rimbick@123'; // DO NOT enter your RMIT password
    $servername = 'talsprddb01.int.its.rmit.edu.au';
    $servicename = 'CSAMPR1.ITS.RMIT.EDU.AU';
    $connection = $servername . "/" . $servicename;

    $conn = oci_connect($username, $password, $connection);
    if (!$conn) {
        $e = oci_error();
        trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
    } else {
        

        $electorate = $_GET['electorate'];
        $voterid = $_GET['voterid'];

        // Query to retrieve candidates from the specified electorate
        $candidatesQuery = "SELECT c.Candidatename, pp.Name
        FROM candidate c
        JOIN politicalparty pp ON c.politicalparty_partycode = pp.partycode
        WHERE c.Electorate_ElectorateName = :electorate";

        $candidatesStid = oci_parse($conn, $candidatesQuery);
        oci_bind_by_name($candidatesStid, ':electorate', $electorate);
        oci_execute($candidatesStid);
    }
    oci_close($conn);
    ?>

   
    <form action="Ballot_Voted.php" method="post">
    
    <?php
    echo '<input type="hidden" name="electorate" value="' . $electorate . '">';
    echo '<input type="hidden" name="voterid" value="' . $voterid . '">';
  ?>

    <div class="container">
    <div class="row mt-4">
        <div class="col-md-12 text-center">
        <img src="https://logowik.com/content/uploads/images/771_australian.jpg" alt="Header Image" width="250" height="200">
            <h3>Victoria Election Division - <?php echo $electorate; ?></h3>
        </div>
    </div>
    <div class="row mt-4">
    <?php
    while ($row = oci_fetch_assoc($candidatesStid)) {
        echo '<div class="col-md-6">';
        echo '<div class="card mb-3 custom-card">'; 
        echo '<div class="card-body">';
        echo '<h5 class="card-title">' . $row['CANDIDATENAME'] . '</h5>';
        echo '<p class="card-text">Party Name: ' . $row['NAME'] . '</p>';
        echo '<label for="preference_' . $row['CANDIDATENAME'] . '">Preference:</label>';
        echo '<input type="number" class="form-control" id="preference_' . $row['CANDIDATENAME'] . '" name="preference[' . $row['CANDIDATENAME'] . ']" min="1" required>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }
    ?>


</div>
<style>
    .custom-card {
        border: 1px solid #000; 
        border-radius: 5px; 
        padding: 10px; 
    }
</style>


</div>

<button type="Submit" class="btn btn-primary custom-button">VOTE</button>

<style>
    .custom-button {
        background-color: #007bff; 
        color: #fff; 
        font-size: 20px; 
        padding: 15px 30px; 
        border: none; 
        border-radius: 5px; 
        cursor: pointer; 
    }

    .custom-button:hover {
        background-color: #0056b3; 
    }
</style>

        
    </form>
</body>
</html>
