oracle user name and passwords

$username = 's3814520';
$password = 'Rimbick@123'; 

website url: https://titan.csit.rmit.edu.au/~s3814520/dba/asg4/index.html