<!DOCTYPE html>
<html>
<head>
    <title>Thank You for Voting</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
        }

        h1 {
            color: #007bff; /* Blue color for the heading */
        }

        p {
            font-size: 18px;
            margin: 20px;
        }

        a {
            text-decoration: none;
            color: #007bff;
            border: 2px solid #007bff;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
        }

        a:hover {
            background-color: #007bff;
            color: #fff;
        }
    </style>
</head>
<body>
    <h1>Thank You for Voting</h1>
    <p>Your vote has been recorded successfully.</p>
    <a href="index.html">Return to Home</a>
</body>
</html>
