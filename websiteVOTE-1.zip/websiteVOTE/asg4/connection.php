<html>
 <head>
  <title>PHP Test with OCI_Connect</title>
 </head>
 <body>
 <?php 
 //echo '<p>Establishing a connection to an Oracle database.</p>';

// Establish a connection to your Oracle database.
$username = 's3814520';
$password = 'Rimbick@123'; //DO NOT enter your RMIT password
$servername = 'talsprddb01.int.its.rmit.edu.au';
$servicename = 'CSAMPR1.ITS.RMIT.EDU.AU';
$connection = $servername . "/" . $servicename;

$conn = oci_connect($username, $password, $connection);
if (!$conn) {
    $e = oci_error();
    trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
} else {
    //echo "<p>Successfully connected to CSAMPR1.ITS.RMIT.EDU.AU.</p>";

 
    $voterFirstName = $_POST['first_name']; 
    $voterLastName = $_POST['last_name'];
    $voterAddress = $_POST['address'];

   
$query = 'SELECT * FROM voterregistry 
WHERE LOWER(firstname) LIKE :fn_bv 
AND LOWER(lastname) LIKE :ln_bv 
AND LOWER(residentaddress) LIKE :resaddress';



$stid = oci_parse($conn, $query);

// Assign form inputs to PHP variables
$first_name = '%' . $_POST['first_name'] . '%';
$last_name = '%' . $_POST['last_name'] . '%';
$resaddress = '%' . $_POST['address'] . '%';

// Convert form inputs to lowercase
$first_name = strtolower($first_name);
$last_name = strtolower($last_name);
$resaddress = strtolower($resaddress);

// Run-time binding of PHP variables to Oracle bind variables
oci_bind_by_name($stid, ':fn_bv', $first_name);
oci_bind_by_name($stid, ':ln_bv', $last_name);
oci_bind_by_name($stid, ':resaddress', $resaddress);


    oci_execute($stid);

    // Check if the combination exists in the electoral register
   $row= oci_fetch_array($stid, OCI_ASSOC);

   
   
   
   if (!$row) {
    echo '<script>alert("Voters information not found");</script>';
    echo '<script>window.location.href = "index.html";</script>';
   }
  
   else {
        
   

    $voterId = $row['VOTERID'];
   
    session_start(); 

  
    $electorate = $row['ELECTORATE_ELECTORATENAME'];

$votedQuery = 'SELECT * FROM voted WHERE voterregistry_voterid like :voter_id';
$votedStid = oci_parse($conn, $votedQuery);
oci_bind_by_name($votedStid, ':voter_id', $voterId);
oci_execute($votedStid);

$votedRow = oci_fetch_assoc($votedStid);

if ($votedRow) {
    // The voter has already voted
    echo '<script>alert("You have already voted. Voter Fraud is a Criminal Offence");</script>';
    echo '<script>window.location.href = "index.html";</script>';
} else {
    echo $votedRow;
    echo '<script>window.location.href = "ballot.php?voterid=' . $voterId . '&electorate=' . $electorate . '";</script>';
   

}

    }
}
?>
 </body>
</html>