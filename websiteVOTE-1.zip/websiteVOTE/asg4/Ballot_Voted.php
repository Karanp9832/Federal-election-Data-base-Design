<?php
// Include your database connection code here
// Establish a connection to your Oracle database.
$username = 's3814520';
$password = 'Rimbick@123'; //DO NOT enter your RMIT password
$servername = 'talsprddb01.int.its.rmit.edu.au';
$servicename = 'CSAMPR1.ITS.RMIT.EDU.AU';
$connection = $servername . "/" . $servicename;

$conn = oci_connect($username, $password, $connection);
if (!$conn) {
    $e = oci_error();
    trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
}
else{
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        
        $electorate = $_POST['electorate'];
        $voterid = $_POST['voterid'];

        
        
$stmt = oci_parse($conn, "
SELECT ELECTIONEVENTID FROM ELECTIONEVENT
WHERE ELECTORATE_ELECTORATENAME = :electorate
");

oci_bind_by_name($stmt, ':electorate', $electorate);
oci_execute($stmt);
$row = oci_fetch_assoc($stmt);

if ($row) {
$electionevent_id = $row['ELECTIONEVENTID'];
// echo $electionevent_id;
// echo $voterid;

//insert voted
$stmt = oci_parse($conn, "
    INSERT INTO voted (votedflag,  voterregistry_voterid, electionevent_electioneventid) 
    VALUES (:votedflag,  :voterid, :electioneventid)
");

$flag = 'YES';
oci_bind_by_name($stmt, ':votedflag',$flag);

oci_bind_by_name($stmt, ':voterid', $voterid);
oci_bind_by_name($stmt, ':electioneventid', $electionevent_id);
oci_execute($stmt);


    $stmt = oci_parse($conn, "select * from Ballot");
        oci_execute($stmt);
        
        $flag = oci_fetch_all($stmt, $rows, null, null, OCI_FETCHSTATEMENT_BY_ROW);
        $ballot_count=$flag+1;
        $flag = oci_fetch_all($stmt, $rows, null, null, OCI_FETCHSTATEMENT_BY_ROW);
        //insert ballot and prefference
        $stmt = oci_parse($conn, "insert into ballot (BALLOTID, ELECTORATE_ELECTORATENAME, ELECTIONEVENT_ELECTIONEVENTID)
        VALUES(:ballotID, :electorate , :electioneventid)");
        oci_bind_by_name($stmt, ':electorate', $electorate);
        oci_bind_by_name($stmt, ':electioneventid', $electionevent_id);
        oci_bind_by_name($stmt, ':ballotID', $ballot_count);
        oci_execute($stmt); 
        header("Location: confirmation.php");
        exit();
        

    
    }
}
}
?>
